import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;

class StudentTest {

	@Test
	void addScoreNormalRange() {
		//Arrange
		Student test = new Student("FirstName", "LastName", "StudentID");
		//Act
		test.addScore(85);
		//Assert
		assertEquals("Score not stored correctly", 85.0, test.getScore(0), .001);
	}
	@Test
	void testLetterGrade() {
		//Arrange
		Student test = new Student("FirstName", "LastName", "StudentID");
		//Act
		//Assert
		assertEquals("A", test.letterGrade(100));
		assertEquals("B", test.letterGrade(80));
		assertEquals("C", test.letterGrade(70));
		assertEquals("D", test.letterGrade(60));
		assertEquals("F", test.letterGrade(50));
	}
	
	@Test
	void testAverage() {
		//Arrange
		Student test1 = new Student("FirstName", "LastName", "StudentID");
		//Act
		test1.addScore(60);
		test1.addScore(90);
		test1.addScore(66);
		test1.addScore(120);
		test1.addScore(70);
		//Assert
		assertEquals("Average not calculated correctly", 77.2, test1.scoreAverage(), 2.0);
	}
	

}
