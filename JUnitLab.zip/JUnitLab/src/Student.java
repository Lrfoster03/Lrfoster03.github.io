import java.util.ArrayList;
import java.util.Scanner;

/**
* @author eelradie
*
*/

public class Student {
	private String firstName;
	private String lastName;
	private String ID;
	private ArrayList<Double> grades = new ArrayList<Double>();

	public Student(String firstName, String lastName, String ID) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.ID = ID;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String getID() {
		return this.ID;
	}

	public void addScore(double grade) {
		// TODO Add method to *remove* a score
		// Ensure that grade is always between 0 and 100
		grade = (grade < 0) ? 0 : grade;
		grade = (grade > 100) ? 100 : grade;
		this.grades.add(grade);
	}

	public double getScore(int index) {
		return this.grades.get(index);
	}

	public double scoreAverage() {
		double sum = 0;
		for (double grade: this.grades) {
			sum += grade;
		}
		return sum / this.grades.size();
	}

	public static String letterGrade(double grade) {
		if (grade >= 90) {
			return "A";
		}
		else if (grade >= 80) {
			return "B";
		}
		else if (grade >= 70) {
			return "C";
		}
		else if (grade >= 60) {
			return "D";
		}
		else {
			return "F";
		}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter first name: ");
		String fn = scanner.next();
		System.out.print("Enter last name: ");
		String ln = scanner.next();
		System.out.print("Enter ID: ");
		String id = scanner.next();
		Student student = new Student(fn, ln, id);
		double temp;
		for (int i = 0; i < 5; i++) {
			System.out.print("Enter score #" + (i+1) + ": ");
			temp = scanner.nextDouble();
			student.addScore(temp);
		}

		System.out.println("The average is: " + student.scoreAverage());
		System.out.println("The letter grade is: " + student.letterGrade(student.scoreAverage()));
	}
}